from django.urls import path
from .views import (
    LastChatMessageListApiView,
    ChatMessageListApiView,
    ChatMessageCreateApiView,
    ChatMessageDestroyApiView,
    ChatBlockUpdateApiView,
    ChatBlockListApiView,
)

urlpatterns=[ 
    # With MongoDB
    path('last-chat-message-list/',LastChatMessageListApiView.as_view()),
    path('chat-message-list/',ChatMessageListApiView.as_view()),
    path('chat-message-create/',ChatMessageCreateApiView.as_view()),
    path('chat-message-delete/',ChatMessageDestroyApiView.as_view()),
    path('chat-block-update/',ChatBlockUpdateApiView.as_view()),
    path('chat-block-list/',ChatBlockListApiView.as_view()),

]