import json
from bson import ObjectId, json_util
from django.core.cache import cache
from django.conf import settings
from django.utils import timezone
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from rest_framework.generics import (
    CreateAPIView,ListAPIView, UpdateAPIView,
    )
from rest_framework.response import Response

from rest_framework.status import (
    HTTP_200_OK,
    HTTP_201_CREATED,HTTP_204_NO_CONTENT,
    )

from fcm.models import FCMDeviceToken
from livekit_stuffs.api.firebase_client import FirebaseClient
from mongodb_connection import MeLiveMongoDB
from profiles.models import Profile
from ..models import ChatCost
from tracking.models import ChatSendVatDiamonds

class LastChatMessageListApiView(ListAPIView):
    authentication_classes = []
    permission_classes = []

    def list(self, request, *args, **kwargs):
        method_dict = request.GET
        user_id = method_dict.get('user_id',0)
        melive_mongo_db = MeLiveMongoDB()

        collection_last_chat_messages = melive_mongo_db["LastChatMessages"]
        last_messages = collection_last_chat_messages.find({'user_id':int(user_id)})

        last_message_list = []
        for last_message in last_messages:
            json_encoded = json.dumps(last_message, sort_keys=True, indent=4, default=json_util.default)
            json_data = json.loads(json_encoded)
            json_data['datetime'] = json_data['datetime']['$date']
            last_message_list.append(json_data)

        return Response(data={'last_message_list':last_message_list},status=HTTP_200_OK)
    
class ChatMessageListApiView(ListAPIView):
    authentication_classes = []
    permission_classes = []

    def list(self, request, *args, **kwargs):
        method_dict = request.GET
        chat_id = method_dict.get('chat_id',"0")
        user_id = int(method_dict.get('user_id',0))
        melive_mongo_db = MeLiveMongoDB()
        collection_chat_messages = melive_mongo_db["ChatMessages"]
        messages = collection_chat_messages.find({'chat_id':chat_id})

        message_list = []
        for message in messages:
            json_encoded = json.dumps(message, sort_keys=True, indent=4, default=json_util.default)
            json_data = json.loads(json_encoded)
            json_data['_id'] = json_data['_id']['$oid']
            json_data['datetime'] = json_data['datetime']['$date']
            message_list.append(json_data)

        is_blocked = False
        receiver_id = 0
        ids = str(chat_id).split("-")
        if int(ids[0]) == user_id:
            receiver_id = int(ids[1]) 
        else:
            receiver_id = int(ids[0]) 

        collection_chat_block = melive_mongo_db["ChatBlock"]
        # Person One Check
        chat_block = collection_chat_block.find({'user_id': user_id}).limit(1)
        try:
            temp = chat_block[0]
            json_encoded = json.dumps(temp, sort_keys=True, indent=4, default=json_util.default)
            json_data = json.loads(json_encoded)
            blocks = json_data['blocks']
            if receiver_id in blocks:
                is_blocked = True
        except:
            is_blocked = False

        # Person Two Check
        if is_blocked == False:
            chat_block = collection_chat_block.find({'user_id': receiver_id}).limit(1)

            try:
                temp = chat_block[0]
                json_encoded = json.dumps(temp, sort_keys=True, indent=4, default=json_util.default)
                json_data = json.loads(json_encoded)
                blocks = json_data['blocks']
                if user_id in blocks:
                    is_blocked = True
            except:
                is_blocked = False

        chat_cost = cache.get(key="chat_cost",)
        if chat_cost is None:
            chat_vat_obj = ChatCost.objects.first()
            if chat_vat_obj is None:
                chat_vat_obj = ChatCost.objects.create()
            chat_cost = {"cost_diamonds": chat_vat_obj.cost_diamonds, "vat_diamonds": chat_vat_obj.vat_diamonds,}
           

        return Response(data={'message_list':message_list,'is_blocked':is_blocked,'chat_cost':chat_cost,},status=HTTP_200_OK)

class ChatMessageCreateApiView(CreateAPIView):
    authentication_classes = []
    permission_classes = []

    def create(self, request, *args, **kwargs):
        data_obj = request.data

        # print(data_obj)
        # return Response(status=HTTP_200_OK)

        key = data_obj.get('key','0')
        chat_id = data_obj.get('chat_id','0')
        sender_id = data_obj.get('sender_id',0)
        receiver_id = data_obj.get('receiver_id',0)
        cost_diamonds = data_obj.get('cost_diamonds',0)
        vat_diamonds = data_obj.get('vat_diamonds',0)

        datetime = timezone.now()
        type = data_obj.get('type','text')
        message = data_obj.get('message','')
        sender_image = data_obj.get('sender_image',None)
        receiver_image = data_obj.get('receiver_image',None)
        sender_full_name = data_obj.get('sender_full_name',None)
        receiver_full_name = data_obj.get('receiver_full_name',None)


        document = {
            'key': key,
            'chat_id': chat_id,
            'sender_id': sender_id,
            'receiver_id': receiver_id,
            'type': type,
            'message': message,
            'datetime': datetime,
        }

        payload_data = {
                "title": sender_full_name,
                "message": message,
                "image": "",
                "peered_uid": f"{receiver_id}",
                "peered_name": receiver_full_name,
                "call_type": "",
                "event_type": "CHAT",
                "channel": chat_id,
        }

        melive_mongo_db = MeLiveMongoDB()
        # Chat Message
        collection_chat_messages = melive_mongo_db["ChatMessages"]
        collection_chat_messages.insert_one(document=document)

        collection_last_chat_messages = melive_mongo_db["LastChatMessages"]

        doc1 = dict(document)
        doc2 = dict(document)

        # Sender Last Message
        doc_id = f"{chat_id}-{sender_id}"
        doc1['user_id'] = sender_id
        doc1['profile_image'] = receiver_image
        doc1['full_name'] = receiver_full_name
        # update_doc = doc1
        doc1['_id'] = doc_id
        try:
            collection_last_chat_messages.insert_one(document=doc1)
        except:
            collection_last_chat_messages.update_one(filter={"chat_id":chat_id, "user_id": sender_id},update={'$set':doc1})

        # Receiver Last Message
        doc2_id = f"{chat_id}-{receiver_id}"
        doc2['user_id'] = receiver_id
        doc2['profile_image'] = sender_image
        doc2['full_name'] = sender_full_name
        # update_doc = doc2
        doc2['_id'] = doc2_id
        try:
            collection_last_chat_messages.insert_one(document=doc2)
        except:
            collection_last_chat_messages.update_one(filter={"chat_id":chat_id, "user_id": receiver_id},update={'$set':doc2})

        device_token = None
        device_obj = FCMDeviceToken.objects.filter(user__id=receiver_id).only('token').first()
        if device_obj:
            device_token = device_obj.token

        if device_token is not None:
            firebase_client = FirebaseClient()
            firebase_client.send_single_fcm(registration_token=device_token,data=payload_data)

        sender_profile_obj = Profile.objects.filter(user__id=sender_id).only('diamonds').first()
        if sender_profile_obj:
            sender_profile_obj.diamonds -= cost_diamonds
            sender_profile_obj.save(force_update=True)

        receiver_profile_obj = Profile.objects.filter(user__id=receiver_id).only('diamonds').first()
        if receiver_profile_obj:
            receiver_profile_obj.diamonds += cost_diamonds - vat_diamonds
            receiver_profile_obj.save(force_update=True)

        track_chat_send_vat_obj =  ChatSendVatDiamonds.objects.first()
        if track_chat_send_vat_obj is None:
            track_chat_send_vat_obj = ChatSendVatDiamonds()
            track_chat_send_vat_obj.chat_vat_diamonds = vat_diamonds
            track_chat_send_vat_obj.save(force_insert=True)
        else:
            track_chat_send_vat_obj.chat_vat_diamonds += vat_diamonds
            track_chat_send_vat_obj.save(force_update=True)

        return Response(status=HTTP_201_CREATED)
    
class ChatMessageDestroyApiView(CreateAPIView):
    authentication_classes = []
    permission_classes = []

    def create(self, request, *args, **kwargs):
        data_obj = request.data
        action = data_obj.get('action',None)
        chat_id = data_obj.get('chat_id',"0")
        melive_mongo_db = MeLiveMongoDB()

        if action == 'last_message':
            user_id = data_obj.get('user_id',0)
            collection_last_chat_messages = melive_mongo_db["LastChatMessages"]
            collection_last_chat_messages.delete_one({'chat_id':chat_id,'user_id':user_id})

            # collection_chat_messages = melive_mongo_db["ChatMessages"]
            # collection_chat_messages.delete_many({'chat_id':chat_id})
            return Response(status=HTTP_200_OK)
        elif action == 'one_message':
            _id = data_obj.get('_id',None)
            key = data_obj.get('key','0')

            collection_chat_messages = melive_mongo_db["ChatMessages"]
            if _id is None:
                collection_chat_messages.delete_one({'key':key,'chat_id':chat_id,})
            else:
                collection_chat_messages.delete_one({'_id':ObjectId(_id),'chat_id':chat_id,})     

            # messages = collection_chat_messages.find({'chat_id':chat_id}).limit(1)

            # try:
            #     temp = messages[0]
            #     # print('Exists')
            # except:
            #     # print('Not Exist') 
            #     collection_last_chat_messages = melive_mongo_db["LastChatMessages"]
            #     collection_last_chat_messages.delete_many({'chat_id':chat_id})          
            return Response(status=HTTP_200_OK)


        return Response(status=HTTP_204_NO_CONTENT)
    
class ChatBlockUpdateApiView(UpdateAPIView):
    authentication_classes = []
    permission_classes = []

    def update(self, request, *args, **kwargs):
        data_obj = request.data
        user_id = data_obj.get('user_id',0)
        chat_id = data_obj.get('chat_id',"0")

        is_blocked = False
        receiver_id = 0
        ids = str(chat_id).split("-")
        if int(ids[0]) == user_id:
            receiver_id = int(ids[1]) 
        else:
            receiver_id = int(ids[0]) 

        melive_mongo_db = MeLiveMongoDB()
        collection_chat_block = melive_mongo_db["ChatBlock"]
        chat_block = collection_chat_block.find({'user_id':user_id}).limit(1)

        try:
            temp = chat_block[0]
            # print('Exists')
            json_encoded = json.dumps(temp, sort_keys=True, indent=4, default=json_util.default)
            json_data = json.loads(json_encoded)
            blocks = json_data['blocks']
            if receiver_id in blocks:
                # Unblock 
                blocks.remove(receiver_id)
                is_blocked = False
            else:
                # Block
                blocks.append(receiver_id)
                is_blocked = True
            collection_chat_block.update_one(filter={"user_id": user_id,},update={'$set':{'blocks':blocks}})
        except:
            # print('Not Exist') 
            is_blocked = True
            collection_chat_block.insert_one({"user_id": user_id,"blocks":[receiver_id]})

        refine_chat_id = str(chat_id).replace('-','_')

        channel_layer = get_channel_layer() 
                
        async_to_sync(channel_layer.group_send)(
            f'chat_room_{refine_chat_id}',
            {
                'type': 'chat_room',  
                'message': {
                    'action': 'update_chat_block',
                    'is_blocked': is_blocked,
                }
            }
        )


        return Response(data={'is_blocked':is_blocked,},status=HTTP_200_OK)
    
class ChatBlockListApiView(ListAPIView):
    authentication_classes = []
    permission_classes = []

    def list(self, request, *args, **kwargs):
        method_dict = request.GET
        user_id = int(method_dict.get('user_id',0))

        melive_mongo_db = MeLiveMongoDB()
        collection_chat_block = melive_mongo_db["ChatBlock"]
        chat_block = collection_chat_block.find({'user_id':user_id}).limit(1)

        block_list = []
        blocks = []

        try:
            temp = chat_block[0]
            # print('Exists')
            json_encoded = json.dumps(temp, sort_keys=True, indent=4, default=json_util.default)
            json_data = json.loads(json_encoded)
            blocks = json_data['blocks']
           
        except:
            # print('Not Exist') 
            pass

        if len(blocks) > 0:
            profile_objs =  Profile.objects.filter(user__id__in=blocks)
            for profile_obj in profile_objs:
                data = {
                    "full_name": profile_obj.full_name,
                    "profile_image": get_profile_image(profile_obj),
                    "user_id": profile_obj.user.id,
                }
                block_list.append(data)

        return Response(data={'block_list':block_list,},status=HTTP_200_OK)
    

def get_profile_image(obj):
    if obj.profile_image:
        return f"{settings.BASE_URL}/media/{obj.profile_image}"
    return obj.photo_url